import os
import tensorflow as tf
import numpy as np
import joblib

class model:
    def __init__(self, path):
        # Load the models
        self.model_cluster0 = tf.keras.models.load_model(os.path.join(path, 'model_cluster0.keras'))
        self.model_cluster1 = tf.keras.models.load_model(os.path.join(path, 'model_cluster1.keras'))
        self.model_cluster2 = tf.keras.models.load_model(os.path.join(path, 'model_cluster2.keras'))
        self.model_cluster3 = tf.keras.models.load_model(os.path.join(path, 'model_cluster3.keras'))
        self.model_cluster4 = tf.keras.models.load_model(os.path.join(path, 'model_cluster4.keras'))
        self.model_cluster5 = tf.keras.models.load_model(os.path.join(path, 'model_cluster5.keras'))
        self.model_cluster6 = tf.keras.models.load_model(os.path.join(path, 'model_cluster6.keras'))
        self.model_cluster7 = tf.keras.models.load_model(os.path.join(path, 'model_cluster7.keras'))
        self.model_cluster8 = tf.keras.models.load_model(os.path.join(path, 'model_cluster8.keras'))

        self.loaded_encoder = tf.keras.models.load_model(os.path.join(path, 'encoder_model.h5'))
        self.loaded_svm = joblib.load(os.path.join(path, 'svm_model.joblib'))

    def predict(self, X, categories):
        # Reshape the input data
        X_reshaped = X.reshape(X.shape[0], 1, X.shape[1])

        encoded_X = self.loaded_encoder.predict(X)
        clusters = self.loaded_svm.predict(encoded_X)

        # Depending on the cluster, use the corresponding model
        out = []

        for i in range(len(X)):
            cluster = clusters[i]

            if cluster == 0:
                out.append(self.model_cluster0.predict(X_reshaped[i])[0])
            elif cluster == 1:
                out.append(self.model_cluster1.predict(X_reshaped[i])[0])
            elif cluster == 2:
                out.append(self.model_cluster2.predict(X_reshaped[i])[0])
            elif cluster == 3:
                out.append(self.model_cluster3.predict(X_reshaped[i])[0])
            elif cluster == 4:
                out.append(self.model_cluster4.predict(X_reshaped[i])[0])
            elif cluster == 5:
                out.append(self.model_cluster5.predict(X_reshaped[i])[0])
            elif cluster == 6:
                out.append(self.model_cluster6.predict(X_reshaped[i])[0])
            elif cluster == 7:
                out.append(self.model_cluster7.predict(X_reshaped[i])[0])
            elif cluster == 8:
                out.append(self.model_cluster8.predict(X_reshaped[i])[0])

        out = np.array(out)

        return out

