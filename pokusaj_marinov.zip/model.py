import os
import tensorflow as tf

class model:
    def __init__(self, path):
        # Load the models
        self.model = tf.keras.models.load_model(os.path.join(path, 'my_model.h5'))

    def predict(self, X, categories):
        X_reshaped = X.reshape((X.shape[0], X.shape[1], 1))
        probabilities = self.model.predict(X)
        return probabilities

